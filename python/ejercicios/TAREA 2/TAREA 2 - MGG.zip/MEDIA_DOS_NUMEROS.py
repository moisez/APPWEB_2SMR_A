#Moisés Gutiérrez Guerrero
#01/10/2024
#CALCULO DE LA MEDIA DE DOS NUMEROS

num1=input("Introduce un numero: ")
num2=input("Introduce otro numero: ")

media_aritmetica = ((eval(num1) + (eval(num2)))/2)

print("La media aricmetica de ", num1, "y", num2, "es", media_aritmetica)