#Moisés Gutiérrez Guerrero
#02/10/2024
#CONVERSOR DE PIES A CENTIMETROS

p = (input("Escriba una cantidad de pies: "))

centimetros = float(p)* (12*2.54)

print(p, "pies son",centimetros,"cm")


