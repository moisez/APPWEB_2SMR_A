#Moisés Gutiérrez Guerrero
#03/10/2024
#Programa que pide una cantidad de segundos y devuelve cuantas horas, minutos y segundos son

segundos=input("Escriba una cantidad de segundo: ")

h = eval(segundos) // 3600
m = (eval(segundos) % 3600) // 60
s = eval(segundos) % 60

print(segundos,"segundos son", h,"horas,",m,"minutos y",s,"segundos")